import 'bootstrap/dist/css/bootstrap.min.css';
import "react-datepicker/dist/react-datepicker.css";
import '../src/Assets/Css/style.css';
import Home from './Pages/home';

function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
