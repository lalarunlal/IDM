import react from "react";

const Label = (props) => {
    return <label>{props.name}</label>
}

export default Label;